# SB_TP1
repositório para o Trabalho Prático 1 da disciplina de Software Basico da Universidade de Brasília (UnB)

Alunos:
- `190125985` José Henrique de Lucas Zeferino
- `170053032` Matheus Virgilio Ferreira

SO utilizado: Linux Kubuntu 24.04
versão do kernel: `6.8.0-51-generic (64-bit)`

instruções para compilar os arquivos separadamente e depois ligá-los:
separadamente:
```
gcc -c montador.cpp -o montador.o
gcc -c src/preprocess_asm_stream.cpp -o preprocess_asm_stream.o
gcc montador.o preprocess_asm_stream.o -lstdc++ -o montador
./montador
```

com um único comando:
```
gcc  montador.cpp  src/preprocess_asm_stream.cpp  -lstdc++  -o  montador
```

****** ****** ****** ****** ****** ****** ****** ****** ****** ****** ****** ******

> **OBS:** implementação do suporte à macros conta como os 3,5 pts da prova.

- [ ] add no `README.md` as instruções de linha de comando para compilar e executar o montador
- [ ] verificar se comentário na seção `DATA` configura erro
- [ ] verificar se a tentativa de alterar o valor armazenado em um rótulo definido como `CONST`, através de instruções `COPY`, deve ser considerada um erro
- [ ] verificar se é necessário explicitar as seções de códigos no Assembly inventado com as linhas `SECTION TEXT` e `SECTION DATA`
- [ ] verificar se a instrução correta é a instrução `MUL` ou `MULT`
- [ ] criar teste para verificar se o `montador` identifica erro de redefinição de macro, i.e. duas macros com o mesmo nome 
- [ ] verificar se, nos arquivos de entrada:
    - [ ] as `MACROS` estarão sempre declaradas antes do `BEGIN`
    - [ ] as `MACROS` podem chamar outras `MACROS` dentro de seu escopo

- [ ] talvez: passar tudo para maiusculo

- [ ] **DÚVIDA:** os símbolos definidos como `CONST` e utilizados em instruções aritméticas não deveriam ser substituidos pelo valor constante definido na seção `DATA`, ao invés do valor do contador de posição?
    - ex: na linha 4 - `L1: DIV DOIS` - do arquivo `ex_asm_sem_ligacao.asm`, o símbolo `DOIS` não deveria ser substituido por `2`, ao invés de `28`?


***

notas de aula:

- apenas usar o `gcc` ou `g++`, para compilar o trabalho
- montador não é *case-sensitive*
- epera-se que o arquivo `.asm` será ligado à outros arquivos `.asm` caso apresente as diretivas `BEGIN` e `END`
- assume-se que o arquivo `.asm` sempre irá apresentar as linhas `SECTION TEXT\n` e `SECTION DATA\n`
- diretiva `SPACE` deve ser representada, no `.obj`, com `0` ou `00` e não `XX`
- maneiras esperadas de executar o montador:
    - se arquivo de entrada for `.asm` - i.e. `./montador file.asm` -, espera-se arq de saída `file.pre` (pré-processado)
    - se arquivo de entrada for `.pre` - i.e. `./montador file.pre` -, espera-se arq de saída `file.obj` (objeto)


- **ex.:** comando para executar o ligador: `./ligador file1.obj file2.obj file3.obj`
- **OBS.:** é permitido e recomendado alterar o conteúdo lido do arquivo de entrada

- sobre `MACROS`:
- **OBS.:** assume-se que que, no arquivo de entrada, há um máximo de até 3 definições de `MACROS`
- **OBS.:** assume-se que essas `MACROS` recebem um valor máximo de até 8 argumentos `MACROS`
- **OBS.:** assume-se que, caso haja múltiplas definições de `MACROS` no arquivo `.asm`:
            - uma `MACRO` pode ser invocada dentro do escopo de outra se, e somente se, a `MACRO` invocada tiver sido definida antes daquela que a está invocando
            - o nome dos parâmetros no espoco de definição de uma `MACRO` podem ser repetidos no escopo de definição de outra. ex: `&op1` é repetido em:
            ```
            BEQ:  MACRO &op1, &op2, &LABEL ; branch to &LABEL if &op1 is equal to &op2
                  ...
                  ENDMACRO

            BGEZ: MACRO &op1, &LABEL       ; branch to &LABEL if &op1 is greater than or equal to 0
                  ...
                  ENDMACRO
            ```


- sobre o ligador:
- **OBS.:** assume-se que não iram ser usados vetores
- **OBS.:** assume-se que o formato correto para a diretiva `BEGIN` é:
    - `MOD_A: BEGIN`


- **OBS.:** arquivos de saída serão criados no mesmo diretório em que se encontrava o arquivo de entrada no momento da execução do montador 
- **LEMBRETE:** ler lista de erros


****** ****** ****** ****** ****** ****** ****** ****** ****** ****** ****** ******

# para testes

```
gcc  -c  montador.cpp  -o  objs/montador.o
gcc  -c  src/preprocess_asm_stream.cpp  -o  objs/preprocess_asm_stream.o
gcc  -c  src/assemble.cpp  -o  objs/assemble.o
gcc  objs/montador.o  objs/preprocess_asm_stream.o  objs/assemble.o  -lstdc++  -o  objs/montador
```

```
./objs/montador  asm/exs/
./objs/montador  asm/exs_slides/
./objs/montador  asm/tests/
#
./objs/montador  asm/exs_slides/ex2_primeira_passagem.pre
```

```
./ligador  file_1.obj  file_2.obj
```
